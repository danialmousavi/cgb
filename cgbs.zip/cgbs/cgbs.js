$(".carousel").owlCarousel({

    loop: true,
    margin: 25,
    autoplay: true,
    autoplayTimeout: 100000,
    autoplayHoverPause: true,
    nav: true,
    navText: ["<img src='images/Variant7.svg' alt=''>", "<img src='images/arrow-right.svg' alt=''>"],
    responsive: {
        0: {
            items: 1,
        },
        600: {
            items: 2,
        },
        1000: {
            items: 3,
        },
        1000: {
            items: 4,
        },

    }
})
const dropdownButton = document.getElementById('dropdown-button');
const dropdownMenu = document.getElementById('dropdown-menu');

dropdownButton.addEventListener('click', () => {
    dropdownMenu.classList.toggle('hidden');
});
function toggleBorderColor(element) {
    var icon = element.querySelector('.icon');
    icon.classList.toggle('icon-rotate');
    if (element.style.borderColor === 'blue') {
        element.style.borderColor = 'gray';
        icon.style.color='gray';
    } else {
        element.style.borderColor = 'blue';
        icon.style.color='blue';
    }
}

